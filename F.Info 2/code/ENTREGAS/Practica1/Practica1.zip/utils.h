void ejercicio1(float &ref);
void ejercicio3(int* pe1, double* pd1, long valor);
int multiplicarVectores(int* v1, int* v2, int n);
void sumaDosMatrices(float *p1, float *p2, float *resultado, int fila, int columna);